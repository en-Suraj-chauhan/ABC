Table of Contents: 

-Installation
-Usage

Installation
Install the requirements from the requirements.txt file.

Usage
The project is about extracting bussiness realted data from raw string,

You can provide your own data either via test_log_parsing file or data file.

Run test cases: 
	open the termimal and run "coverage run -m pytest"
	(This will generate one .coverage file)

Generate coverage report:
	To see coverage report run "coverage report" command in terminal

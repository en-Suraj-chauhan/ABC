import pytest
from main import create_dict_from_list, parse_system_logs

@pytest.fixture
def sample_list():
    return ['name=John', 'age=25', 'city=New York']

@pytest.fixture
def sample_log_string():
    return "timestamp|user|cat=C2 msg=System initialized successfully code=200 cs1=DNS_TUNNELING"

def test_create_dict_from_list(sample_list):
    result_dict = create_dict_from_list(sample_list)
    assert result_dict == {'name': 'John', 'age': '25', 'city': 'New York'}

def test_parse_system_logs(sample_log_string):
    parsed_logs = parse_system_logs(sample_log_string)
    assert parsed_logs == ['cat=C2', ' msg=System initialized successfully', 'code=200', 'cs1=DNS_TUNNELING']


# Importing data from data file.
from Data.data import input_string1, input_string2

def create_dict_from_list(lst):
    """
    Creates a dictionary from a list of strings where each string represents a key-value pair.

    The function assumes that each string in the list follows the format 'key=value'.
    It splits each string at the first occurrence of the '=' character to extract the key and value,
    and then assigns the key-value pair to a dictionary.

    Args:
        lst (list): A list of strings in the format 'key=value'.

    Returns:
        dict: A dictionary containing key-value pairs extracted from the list.

    Example:
        lst = ['name=John', 'age=25', 'city=New York']
        result_dict = create_dict_from_list(lst)
        # result_dict will be {'name': 'John', 'age': '25', 'city': 'New York'}
    """

    # Creating a blank dictionary to store data in key:value pair from list elements.
    result_dict = {}

    # Iterating over all elements and finding the index of char '=' using sliceing and generating result dict. 
    for item in lst:
    	index = item.index('=')
    	key = item[:index]
    	value = item[index + 1:]
    	result_dict[key] = value

    return result_dict

def parse_system_logs(log_string):
    """
    Parses a system log string and extracts relevant information.

    Args:
        log_string (str): The system log string to be parsed.

    Returns:
        list: A list containing the extracted log information.

    Example:
        log_string = "timestamp|user|cat=C2 msg=System initialized successfully code=200 cs1=DNS_TUNNELING"
        parsed_logs = parse_system_logs(log_string)
        # parsed_logs will be ['cat=C2', ' msg=System initialized successfully', 'code=200', 'cs1=DNS_TUNNELING']
    """

    # Creating a blank list for storing every segment of data.
    main_list = list()

    #spliting the whole string into list of segments.
    segments = log_string.split(' ')

    # Extracting the required data from first segment.
    segments[0] = segments[0].split('|')[-1]
    
    # Extracting last two segments and deleting from segments list to merge all message segments. 
    dhost_dst = segments[-2:]
    del segments[-2:]

    # Merging all message segments into one message and populating the main list.
    message = ""
    start_concatenation = False    
    for element in segments:
    	if element.startswith('msg='):
    		start_concatenation = True
    	if start_concatenation:
    		message = message +" "+ element
    	else:
    		main_list.append(element)

    # Adding message and last two segments in main list
    main_list.append(message)
    main_list.extend(dhost_dst)

    return main_list
    
if __name__ == '__main__':
    list_of_segments = parse_system_logs(input_string1)
    result = create_dict_from_list(list_of_segments)
    print(result)
